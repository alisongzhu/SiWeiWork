// Header:
// File Name: iec104_handler.h
// Author:LH
// Date: Aug 16 2017

#ifndef _IEC104_HACDLER_H_
#define _IEC104_HACDLER_H_

//extern uint64_t TimeSelectOn;

void IEC104_init(void);

#endif  /*_IEC104_HACDLER_H_*/
