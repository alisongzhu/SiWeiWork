/*
 * dtu.h
 *
 *  Created on: 22 Jan 2018
 *      Author: alien
 */

#ifndef INC_DTU_H_
#define INC_DTU_H_

void DTU_init(void);


#endif /* INC_DTU_H_ */
