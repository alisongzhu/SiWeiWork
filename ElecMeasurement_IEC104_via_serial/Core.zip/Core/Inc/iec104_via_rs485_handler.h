/*
 * iec104_via_rs485_handler.h
 *
 *  Created on: 2018年12月14日
 *      Author: alien
 */

#ifndef CORE_INC_IEC104_VIA_RS485_HANDLER_H_
#define CORE_INC_IEC104_VIA_RS485_HANDLER_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

/* Macros --------------------------------------------------------------------*/

/* Types ---------------------------------------------------------------------*/

/* Constants -----------------------------------------------------------------*/

/* Global Variables ----------------------------------------------------------*/

/* Function Prototypes -------------------------------------------------------*/
void vTaskIEC104(void const * argument);

#ifdef __cplusplus
}
#endif

#endif /* CORE_INC_IEC104_VIA_RS485_HANDLER_H_ */
